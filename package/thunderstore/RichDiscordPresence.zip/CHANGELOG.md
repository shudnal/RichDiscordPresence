# 1.0.5
* terminal command fix

# 1.0.4
* little fix for safe in home and main menu status calculation
* patch 0.217.38

# 1.0.3
* got rid of steam id entirely

# 1.0.2
* non steam PC version support

# 1.0.1
* option to localize boss, biome and location names on selected language

# 1.0.0
* Initial release